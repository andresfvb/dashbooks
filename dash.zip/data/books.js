const allBooks = [
    {
        nameBook: 'Don quijote de la mancha',
        autor: 'Miguel de Cervantes',
        editorial: 'Los tres editores',
        codLibro: 'bJY7kF-3',
        state: 'disponible',
        avatar: 'https://www.polifemo.com/static/img/portadas/_visd_0000JPG01YMC.jpg',
        id: 1
    },
    {
        nameBook: 'El principito',
        autor: 'Antonie de SAint-Exupery',
        editorial: 'Alfaomega Colombiana',
        codLibro: 'nkE7nr-9',
        state: 'disponible',
        avatar: 'https://www.penguinlibros.com/co/1696231/el-principito-edicion-oficial.jpg',
        id: 2
    },
    {
        nameBook: 'La culpa es de la vaca',
        autor: 'Jaime Lopera',
        editorial: 'Angosta Editores',
        codLibro: 'PoTnm_-9',
        state: 'disponible',
        avatar: 'https://www.planetadelibros.com.co/usuaris/libros/fotos/332/m_libros/portada_selecciones-de-la-culpa-es-de-la-vaca_jaime-lopera_202103261526.jpg',
        id: 3
    },
]

export default allBooks