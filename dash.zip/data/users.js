const allUsers = [
    {
        id: 1,
        nameUser: 'admin',
        rol: 'admin',
        contraseña: '12345',
        firstName: 'Admin',
        lastName: 'Controller',
        login: false
    },
    {
        id: 2,
        nameUser: 'user',
        rol: 'client',
        contraseña: '12345',
        firstName: 'Andres',
        lastName: 'Vasquez',
        login: false
    }
]

export default allUsers