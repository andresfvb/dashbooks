import React from 'react'
import styles from '@/styles/header.module.css'
const Header = () => {
    return (
        <div>
            <div className={styles.cabecera}><h1>Hola mundo</h1></div>
        </div>
    )
}

export default Header