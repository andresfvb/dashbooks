import React from 'react'
import { Card,Button, CardHeader, CardBody, CardFooter, Divider, Link, Image } from "@nextui-org/react"
import Cookies from 'js-cookie'

const UseBook = ({carga, onClose, setCarga}) => {
    const prestar = async (e) => {
        setCarga({ name: '', editorial: '', author: '', cod: '', id: '', avatar:'' })
        const formData = {
            nameBook: carga.name,
            codLibro: carga.cod,
            avatar: carga.avatar,
            state: "ocupado",
            user: Cookies.get('email')
        }
        await fetch('api/users', {
            method: 'POST',
            body: JSON.stringify(formData),
        })
    }
  return (
    <div>
        <Card>
                                        <CardBody className='flex flex-row gap-5 justify-around '>
                                            <div>
                                                <Image src={carga.avatar} width={200} height={200}/>
                                            </div>
                                            <div className='flex flex-col gap-y-8'>
                                                <h1 className='text-medium'>{carga.name}</h1>
                                                <div>
                                                <p>Autor:</p><p>{carga.author}</p>

                                                </div>
                                                <div>
                                                <p>Editorial:</p><p>{carga.editorial}</p>

                                                </div>
                                                <div>
                                                <p>Estado:</p><p>{carga.state}</p>

                                                </div>
                                                <div>
                                                <Button onPress={onClose}  className="w-full" color="success" variant="ghost" onClick={()=>prestar()}>
                                                    Solicitar
                                                </Button>
                                                </div>
                                            </div>
                                        </CardBody>
                                        </Card>
    </div>
  )
}

export default UseBook