import React, { useEffect, useContext, useState } from 'react';
import { Table, TableHeader, TableColumn, TableBody, TableRow, TableCell, User, Chip, Tooltip, getKeyValue, Button } from "@nextui-org/react";
import BooksContext from '@/src/context/books/booksContext';
import { EditIcon } from '@/public/image/Editcon';
import { DeleteIcon } from '@/public/image/DeleteIcon';
import { supabase } from '@/src/pages/api/auth/[...auth]';
import { EyeIcon } from '@/public/image/EyeIcon';
import Cookies from 'js-cookie';


const BooksUse = ({ onOpen, setEdicion, carga, setCarga }) => {

    const eliminar = async (item) => {
        await fetch('api/user', {
            method: 'DELETE',
            body: JSON.stringify(item),
        })
        // setCarga({ name: '', cod: '', avatar:'' })
    }
    const statusColorMap = {
        disponible: "success",
        ocupado: "danger",
    };
    const renderCell = React.useCallback((user, columnKey) => {
        const cellValue = user[columnKey];

        switch (columnKey) {
            case "name":
                return (
                    <User
                        avatarProps={{ radius: "lg", src: user.avatar }}
                        description={user.email}
                        name={cellValue}
                    >
                        {user.email}
                    </User>
                );
            case "cod":
                return (
                    <div className="flex flex-col">
                        <p className="text-bold text-small capitalize">{cellValue}</p>

                    </div>
                );
            case "author":
                return (
                    <div className="flex flex-col">
                        <p className="capitalize" >
                            {cellValue}
                        </p>
                    </div>
                );
            case "state":
                return (
                    <Chip className="capitalize" color={statusColorMap[user.state]} size="sm" variant="flat">
                        {cellValue}
                    </Chip>
                );
            case "editorial":
                return (
                    <div className="flex flex-col">
                        <p className="capitalize" >
                            {cellValue}
                        </p>
                    </div>
                );
            case "actions":
                return (
                    <div className="relative flex items-center gap-5">
                        <Tooltip color="danger" content="Entregar Libro">
                            <span className="text-medium text-danger cursor-pointer active:opacity-50" onClick={() => eliminar(user)}>
                                <DeleteIcon />
                            </span>
                        </Tooltip>
                       
                    </div>
                );
            default:
                return cellValue;
        }
    }, []);


    const { booksUser, getAllBooksUser } = useContext(BooksContext)
    useEffect(() => {
        getAllBooksUser(Cookies.get('email'))
    }, [carga])
    const columns = [
        {
            uid: 'id',
            label: "#"
        },
        {
            uid: 'cod',
            label: "Codigo"
        },
        {
            uid: 'name',
            label: "Libro"
        },
        {
            uid: 'actions',
            label: "Acciones"
        }
    ];

    const rows = [];
    booksUser.forEach((element, index) => {
        rows.push({ id: index+1, cod: element.codLibro, name: element.nameBook, avatar: element.avatar })
    })
    return (
        <Table removeWrapper aria-label="Example table with custom cells">
            <TableHeader columns={columns}>
                {(column) => (
                    <TableColumn className="text-medium" key={column.uid} align={column.uid === "actions" ? "center" : "start"}>
                        {column.label}
                    </TableColumn>
                )}
            </TableHeader>
                    <TableBody items={rows}>
                        {(item) => (
                            <TableRow className="text-small" key={item.id}>
                                {(columnKey) => <TableCell>{renderCell(item, columnKey)}</TableCell>}
                            </TableRow>
                        )}
                    </TableBody>
        </Table>
    )
}

export default BooksUse