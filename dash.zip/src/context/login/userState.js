import { useEffect, useReducer } from 'react'
import userReducer from './userReducer'
import axios from 'axios'
import UserContext from './userContext'


const UserState = (props) => {
    const initialState = {
        rolLog: '',
    }
    const [state, dispatch] = useReducer(userReducer, initialState)
    const getRol = (rol) => {
        try {
            dispatch({
                type: 'GET_USER',
                payload: rol,
            })
        } catch (error) {
            console.error(error);
        }
    }

    return (
        <UserContext.Provider
            value={{
                rolLog: state.rolLog,
                getRol
            }}
        >
            {props.children}
        </UserContext.Provider>
    )
}

export default UserState